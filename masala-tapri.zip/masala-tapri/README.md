# Masala Tapri

A responsive five-page static website for a small chai shop, built with plain HTML, CSS and JavaScript.

## Pages
- `index.html` Home
- `menu.html` Menu with category filter
- `about.html` About
- `contact.html` Contact form with validation
- `404.html` Not-found page

## Run locally
```
python3 -m http.server 8000
```
Open http://localhost:8000

## Deploy
Hosted on Cloudflare Pages. Build command: none. Output directory: `/`.
