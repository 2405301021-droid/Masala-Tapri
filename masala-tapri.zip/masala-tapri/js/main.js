// Masala Tapri — small enhancements
(function () {
  // Mobile navigation
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Footer year
  var year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  // Menu filters
  var chips = document.querySelectorAll('.chip');
  var groups = document.querySelectorAll('.menu-group');
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      var cat = chip.getAttribute('data-filter');
      chips.forEach(function (c) { c.setAttribute('aria-pressed', String(c === chip)); });
      groups.forEach(function (g) {
        g.hidden = !(cat === 'all' || g.getAttribute('data-cat') === cat);
      });
    });
  });

  // Contact form validation
  var form = document.getElementById('contact-form');
  if (form) {
    var notice = document.getElementById('form-notice');
    var rules = {
      name: function (v) { return v.trim().length >= 2 ? '' : 'Enter your name (at least 2 characters).'; },
      email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? '' : 'Enter a valid email address, like name@example.com.'; },
      message: function (v) { return v.trim().length >= 10 ? '' : 'Write a message of at least 10 characters.'; }
    };
    var check = function (field) {
      var input = form.elements[field];
      var msg = rules[field](input.value);
      document.getElementById(field + '-error').textContent = msg;
      input.setAttribute('aria-invalid', msg ? 'true' : 'false');
      return !msg;
    };
    Object.keys(rules).forEach(function (f) {
      form.elements[f].addEventListener('blur', function () { check(f); });
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var ok = Object.keys(rules).map(check).every(Boolean);
      if (!ok) {
        var firstBad = form.querySelector('[aria-invalid="true"]');
        if (firstBad) firstBad.focus();
        return;
      }
      notice.textContent = 'Thanks, ' + form.elements.name.value.trim() + '. We got your message and will reply to ' + form.elements.email.value.trim() + ' within a day.';
      notice.hidden = false;
      form.reset();
    });
  }
})();
